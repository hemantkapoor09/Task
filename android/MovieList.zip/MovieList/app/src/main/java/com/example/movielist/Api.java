package com.example.movielist;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api {
    String BASE_URL = "http://www.omdbapi.com/?s=Home";
    String KEY = "&apikey=94a221d";

    @GET("&apikey=94a221d")
    Call<List<Movies>> getMovies();

}
